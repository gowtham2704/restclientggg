import { Component, OnInit } from '@angular/core';
import { User } from '../../user';
import { Router } from '@angular/router';
import { UserService } from '../../shared_service/user.service';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {

  private user:User;
  constructor(private userservice:UserService,private router:Router) { }

  ngOnInit() {

    this.user=this.userservice.getter();
  }
  processForm()
  { 
    if(this.user.id==undefined)
    {
      this.userservice.createEmployee(this.user).subscribe((user)=>{
        console.log(user);
        this.router.navigate(['/']);
      },(error)=>{
        console.log(error);
      });
    }else{
      this.userservice.updateEmployee(this.user).subscribe((user)=>{
        console.log(user);
        this.router.navigate(['/']);
      },(error)=>{
        console.log(error);
      });
    }
  }
}