export class User {
    id:number;
    fname:String;
    lname:String;
}